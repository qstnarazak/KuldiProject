package com.example.kuldilesson

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
